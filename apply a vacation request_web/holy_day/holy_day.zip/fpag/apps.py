from django.apps import AppConfig


class FpagConfig(AppConfig):
    name = 'fpag'
