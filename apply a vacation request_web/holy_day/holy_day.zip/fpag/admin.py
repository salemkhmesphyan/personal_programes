from django.contrib import admin
from fpag.models import Reqi_holy
# Register your models here.

admin.site.register(Reqi_holy)
# Register your models here.
