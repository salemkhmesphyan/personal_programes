import os
os.system("python3 manage.py runserver")
