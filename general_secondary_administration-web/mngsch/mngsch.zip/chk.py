import sqlite3
l=1
t=sqlite3.connect("mngschool1.db")
cb=t.cursor()
cb.execute("select * from qran  where namst='hany2'union all select * from qran2  where namst='hany2'")
df=cb.fetchall()
cb.execute("select * from ajtm  where namst='omr'union all select * from ajtm2  where namst='omr'")
df2=cb.fetchall()
print(len(df))
for n,n2 in zip(df,df2):
	if l==1:
		print(n[6]+"1,")
		
		
	if l==2:
		print(n[6]+"2,")
	if l==3:
		print(n[6]+"3")
	l+=1
			
	
