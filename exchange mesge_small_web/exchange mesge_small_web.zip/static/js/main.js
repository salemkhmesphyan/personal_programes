function test() {
document.execCommand("SaveAs");}
var name=new Date()
//var ajax=new XMLHttpRequest();
//ajax.open("get","")
